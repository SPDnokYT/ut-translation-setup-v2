extends Control

signal comment_hide

const CCComment = preload("res://data/clickclock/CCComment.gd")
const CCCommentView = preload("res://ui/components/CCComment/CCComment.tscn")
const CCVideo = preload("res://data/clickclock/CCVideo.gd")

@onready var close_btn = $VBoxContainer/Topbar/CloseBtn
@onready var comment_count_label = $VBoxContainer/Topbar/CommentCount
@onready var comment_list = $VBoxContainer/ScrollContainer/Margin/CommentList
@onready var comment_scroll_container = $VBoxContainer/ScrollContainer
@onready var choice_box = $VBoxContainer/CommentChoiceBox
@onready var no_comments_container = $NoComments
@onready var disable_comment_label = $DisableComment

var video_data : CCVideo

func _ready():
	close_btn.pressed.connect(_on_close_btn_pressed)
	choice_box.chosen.connect(_on_choice_box_chosen)
	comment_list.visible = false
	no_comments_container.visible = false
	disable_comment_label.visible = false
	
func _on_close_btn_pressed():
	comment_hide.emit()
	
func setup_comments(_video_data):
	video_data = _video_data
	video_data.comments_changed.connect(_on_comments_changed)
	
	_update_comments()	
	_update_choices()


func set_comment_count(comment_count: int):
	var word = "комментариев"
	var last_digit = comment_count % 10
	var last_two = comment_count % 100
	
	if last_two >= 11 and last_two <= 14:
		word = "комментариев"
	elif last_digit == 1:
		word = "комментарий"
	elif last_digit >= 2 and last_digit <= 4:
		word = "комментария"
	
	comment_count_label.text = str(comment_count) + " " + word
	
func _on_comments_changed():
	for child in comment_list.get_children():
		comment_list.remove_child(child)
		child.queue_free()
	await get_tree().process_frame
	_update_comments()


func _on_choice_box_chosen(_idx: int):
	_update_choices()
	await Utils.wait_frames(4)
	comment_scroll_container.scroll_to_end()

	
func _update_comments():
	var comments = video_data.ordered_comment_replies()
	var count = comments.size()
	
	if not video_data.allow_comments:
		disable_comment_label.visible = true
		return
	
	if comments.is_empty():
		no_comments_container.visible = true
		return
	
	for i in range(count):
		var comment: CCComment = comments[i]
		if not has_node(comment.uid):
			var comment_view = CCCommentView.instantiate()
			comment_view.comment = comment
			comment_view.op_username = video_data.username
			comment_view.op_dp_ref = video_data.user_dp_ref
			comment_list.add_child(comment_view)
	
	comment_list.visible = true
	set_comment_count(video_data.comment_count)


func _update_choices():
	var choose_func: Callable
	var choices = []
	
	choices = video_data.choice_comments()
	choose_func = video_data.choose_comment

	choice_box.choose_func = choose_func
	choice_box.choices = choices
	
func grab_focus():
	pass
	
