extends "res://ui/screens/Screen.gd"

const ANIM_MARGIN = 12
const NATURAL_LOG_E = 2.718281828459
const MAX_STORED_FRAMES = 128
const ARTIFACTS_PRESETS = [
		[1, 4.0],
		[1, 3.5],
		[2, 3.0],
		[3, 2.25],
		[4, 1.5],
	]


const RingBuffer = preload("res://ui/screens/VideoCallScreen/lib/RingBuffer.gd")


@export var lag_duration_range = Vector2(0.0, 1.5) #s
@export var time_between_lags_range = Vector2(1.0, 3.0) #s
@export var call_camera: Camera3D
@export var self_camera: Camera3D
@export var control_anim_duration: float = 0.4
@export var start_controls_hidden = true
@export var lag_rate: float = 0.0: set = set_lag_rate
@export var lag_reduces_quality = false
@export var lag_stretches_video = false:
	set(v):
		lag_stretches_video = v
		video_frame.visible = lag_stretches_video
@export var fast_forward_speed: int = 4

@onready var sub_viewport = $FeedContainer/VideoCallFeed/SubViewport
@onready var video_call_feed = $FeedContainer/VideoCallFeed
@onready var video_frame = $FeedContainer/Frame
@onready var end_call_delay_timer = $EndCallDelayTimer
@onready var freeze_feed_timer = $FreezeFeedTimer
@onready var animation_player = $AnimationPlayer
@onready var no_video_container = $NoVideoContainer
@onready var top_bar = $TopBar
@onready var bottom_bar = $BottomBar
@onready var end_call_button = $BottomBar/MarginContainer/ButtonsContainer/EndCall/PanelContainer/Button
@onready var name_label = $TopBar/MarginContainer/VBoxContainer/NameLabel
@onready var lag_threshold_timer = $LagThresholdTimer
@onready var wifi_off = $FeedContainer/WifiOff
@onready var wifi_on = $FeedContainer/WifiOn

var _camera_cache = {}

var _command_handler = _run_command

var _old_parent
var _top_anchor_y
var _bottom_anchor_y
var _artifacts_level: int = 0: set = set_artifacts_level
var _artifacts_level_decayable: float = 0.0:
	set(v):
		_artifacts_level_decayable = max(v, 0.0)
		_render_artifacts()

var _artifacts_level_decay_coefficient: float = 3.0
var _artifacts_time_since_last_set: float = 0.0

var _lagged_frames_buffer = RingBuffer.new(MAX_STORED_FRAMES) #RingBuffer of Image s
var _frame_counter = 0
var _paused = false

func _enter_tree():
	Story.add_command_handler(_command_handler)

func _exit_tree():
	Story.remove_command_handler(_command_handler)

func _run_command(cmd: Command):
	var params = cmd.params

	match cmd.name:
		"video_call":
			if params.is_empty():
				return Constants.CMD_RETURN_NONE
			
			match params[0]:
				"pause":
					pause_feed()
				"resume":
					resume_feed()
				"hide_controls":
					hide_controls()
				"show_controls":
					show_controls()
				"set_camera":
					if params.size() < 2:
						return Constants.CMD_RETURN_NONE
					change_camera(params[1])
				"set_artifacts_level": #0-4
					if params.size() < 2:
						return Constants.CMD_RETURN_NONE
					set_artifacts_level(int(params[1]))
				"set_lag_rate": #0.0-1.0
					if params.size() < 2:
						return Constants.CMD_RETURN_NONE
					set_lag_rate(float(params[1]))
				"set_stretch_fast_forward_speed":
					if params.size() < 2:
						return Constants.CMD_RETURN_NONE
					set_stretch_fast_forward_speed(params[1])
				"lag_reduces_quality": #0 1
					if params.size() < 2:
						return Constants.CMD_RETURN_NONE
					#seems like there's already a check in place for true/false
					#we can set this directly
					lag_reduces_quality = params[1]
				"lag_stretches_video": #0 1
					if params.size() < 2:
						return Constants.CMD_RETURN_NONE
					#seems like there's already a check in place for true/false
					#we can set this directly
					lag_stretches_video = params[1]

		_:
			return Constants.CMD_RETURN_NONE

	return null

func _ready():
	_top_anchor_y = top_bar.position.y
	_bottom_anchor_y = bottom_bar.position.y
	
	if start_controls_hidden:
		hide_controls()

	if !get_tree().root.is_node_ready():
		await get_tree().root.ready

	_cache_cameras()
	_take_over(call_camera)

	if meta.has("caller_id"):
		var caller_names = {
			"Alissa": "Алисса"
		}
		var caller_id = meta["caller_id"]
		name_label.text = caller_names.get(caller_id, caller_id)

	end_call_button.pressed.connect(_on_end_call_pressed)
	
	lag_threshold_timer.timeout.connect(_on_lag_threshold_timer_timeout)
	lag_threshold_timer.start(randf_range(time_between_lags_range.x, time_between_lags_range.y))

func _process(delta):
	if _artifacts_level_decayable > 0.25:
		_artifacts_level_decayable = _artifacts_level_decayable * pow(NATURAL_LOG_E, -_artifacts_level_decay_coefficient * _artifacts_time_since_last_set)
		
	else:
		_artifacts_level_decayable = 0
	
func _physics_process(delta):
	if !lag_stretches_video:
		return

	if is_video_feed_paused():
		if _frame_counter % fast_forward_speed == 0:
			_lagged_frames_buffer.write(sub_viewport.get_texture().get_image())
		#video_frame.texture = sub_viewport.get_texture()
		_frame_counter += 1
	
	elif not _lagged_frames_buffer.is_empty():
			video_frame.texture = ImageTexture.create_from_image(_lagged_frames_buffer.read())
		
	else:
		#we ran out of frames, just show the camera tex
		video_frame.texture = sub_viewport.get_texture()

func show_video_feed():
	if call_camera:
		_take_over(call_camera)
		call_camera.current = true

func _take_over(camera_node):
	if !camera_node:
		sub_viewport.transparent_bg = true
		no_video_container.show()
		return
	
	sub_viewport.transparent_bg = false
	no_video_container.hide()
	
	_old_parent = camera_node.get_parent()
	camera_node.reparent(sub_viewport)
	
	camera_node.current = true

func _release(camera_node):
	if !camera_node:
		return
	
	#camera_node.queue_free()
	
	camera_node.current = false
	camera_node.reparent(_old_parent)

func change_camera(camera_name: String = ""):
	var new_camera
	if camera_name in _camera_cache:
		new_camera = _camera_cache[camera_name]
	else:
		new_camera = null

	if call_camera == new_camera:
		return
	
	
	if _old_parent:
		_release(call_camera)

	_take_over(new_camera)
	call_camera = new_camera


func pause_feed():
	if !lag_stretches_video:
		sub_viewport.render_target_update_mode = sub_viewport.UPDATE_DISABLED
		_paused = true
		return
	var still = sub_viewport.get_texture().get_image()
	video_frame.texture = ImageTexture.create_from_image(still)
	_lagged_frames_buffer.clear()
	_paused = true

func resume_feed():
	_frame_counter = 0
	if !lag_stretches_video:
		sub_viewport.render_target_update_mode = sub_viewport.UPDATE_ALWAYS
		_paused = false
		return

	video_frame.texture = sub_viewport.get_texture()
	_paused = false

func is_video_feed_paused():
	#return sub_viewport.render_target_update_mode == sub_viewport.UPDATE_DISABLED
	return _paused

func set_artifacts_level(level: int):
	_artifacts_level = level

	_render_artifacts()
	
func _render_artifacts():
	var effective_artifacts_level: int = _artifacts_level + int(_artifacts_level_decayable)
	effective_artifacts_level = clamp(effective_artifacts_level, 0, ARTIFACTS_PRESETS.size() - 1)
	
	video_call_feed.stretch_shrink = ARTIFACTS_PRESETS[effective_artifacts_level][0]
	video_call_feed.material.set_shader_parameter("posterize_steps", ARTIFACTS_PRESETS[effective_artifacts_level][1])

func set_lag_rate(rate: float = 0.0):
	lag_rate = clamp(rate, 0.0, 1.0)

func set_stretch_fast_forward_speed(speed):
	fast_forward_speed = int(max(speed, 1.0))

var show_controls_tween
func hide_controls():
	end_call_button.release_focus()
	end_call_button.focus_mode = FOCUS_NONE
	
	if show_controls_tween:
		show_controls_tween.kill()

	show_controls_tween = create_tween()
	
	show_controls_tween.tween_property(bottom_bar, "position:y", _bottom_anchor_y + bottom_bar.size.y - ANIM_MARGIN , control_anim_duration)
	show_controls_tween.set_trans(Tween.TRANS_BACK)
	show_controls_tween.set_ease(Tween.EASE_OUT)


func show_controls():
	if show_controls_tween:
		show_controls_tween.kill()

	show_controls_tween = create_tween()
	
	show_controls_tween.tween_property(bottom_bar, "position:y", _bottom_anchor_y, control_anim_duration)
	show_controls_tween.set_trans(Tween.TRANS_BACK)
	show_controls_tween.set_ease(Tween.EASE_OUT)
	
	await show_controls_tween.finished
	end_call_button.focus_mode = FOCUS_ALL
	end_call_button.call_deferred("grab_focus")


func _debug_cycle_camera_feeds():
	if _camera_cache.size() <= 0:
		printerr("Tried to cycle through cameras but no camera feeds in cache")

	var keys = _camera_cache.keys()

	var idx = 0
	if call_camera:
		idx = keys.find(call_camera.name)
	
	var next = keys[(idx + 1) % keys.size()]
	change_camera(next)


func _cache_cameras():
#	for c in sub_viewport.get_children():
#		c.queue_free()
		
	if _camera_cache.size() <= 0:
		#FIXME: expensive op
		for c in get_tree().root.find_children("*", "Camera3D", true, false):
#			var dupe = c.duplicate()
#			sub_viewport.add_child(dupe)
			_camera_cache[c.name] = c 


func _on_end_call_pressed():
	if !end_call_delay_timer.is_stopped():
		return
	
	pause_feed()
	freeze_feed_timer.start()
	await freeze_feed_timer.timeout
	animation_player.play("close_camera")
	await animation_player.animation_finished
	resume_feed()
	change_camera("")
	end_call_delay_timer.start()
	await end_call_delay_timer.timeout
	back_pressed.emit()

func _on_lag_threshold_timer_timeout():
	if is_video_feed_paused():
		#something is keeping the feed paused, ignore lag
		return
		
	#only lag if we win rng
	var rng = randf()
	if rng > lag_rate:
		return
	
	wifi_off.show()
	#wifi_on.hide()
	pause_feed()
	var variable_lag_rate = clamp(lag_rate * lag_rate * randf_range(0.5, 1.2) + lag_rate * lag_rate, 0.0, 1.0)
	var variable_lag_time = randf_range(lag_duration_range.x, lag_duration_range.y)
	await get_tree().create_timer(variable_lag_time).timeout
	resume_feed()
	
	get_tree().create_timer(3).timeout.connect(func (): wifi_off.hide())
	
	if lag_reduces_quality:
		_artifacts_level_decayable = int(lerp(0, 4, randf()))
		_artifacts_time_since_last_set = 0.0

func _unhandled_input(event):
	if event.is_action_pressed("d_up"):
		end_call_button.grab_focus()