extends Button

const FbQuark = preload("res://data/fb/FbQuark.gd")
const DEFAULT_COLOR = Color.DIM_GRAY

@onready var reaction_bar = $FbReactionBar
@onready var label = $Label

var quark: FbQuark:
	set = _set_quark,
	get = _get_quark

var like_checker : DirtyChecker
var reaction_checker : DirtyChecker

var is_active: bool

func _ready():
	pressed.connect(_on_button_pressed)
	reaction_bar.scale.y = 0
	is_active = false
	reaction_bar.reaction_selected.connect(_on_reaction_selected)
	reaction_bar.bar_hidden.connect(_on_reaction_bar_hidden)
	
func toggle_reaction_bar():
	is_active = not is_active
	reaction_bar.is_active = not reaction_bar.is_active
	if reaction_bar.is_active:
		reaction_bar.show_anim()
	else:
		reaction_bar.hide_anim()

func set_reaction_info(reaction_text,color):
	label.text = reaction_text
	label.add_theme_color_override("font_color",color)	
	
func _set_quark(value):
	if value == null:
		return
		
	var old_quark = quark
	quark = value
	reaction_bar.quark = quark
	_on_reaction_changed()
	
	if old_quark:
		like_checker.changed.disconnect(_on_like_changed)
		like_checker.queue_free()
		
		reaction_checker.changed.disconnect(_on_reaction_changed)
		reaction_checker.queue_free()
	if quark:
		like_checker = DirtyChecker.new(quark, "liked")
		like_checker.changed.connect(_on_like_changed)
		add_child(like_checker)
		
		reaction_checker = DirtyChecker.new(quark, "reaction")
		reaction_checker.changed.connect(_on_reaction_changed)
		add_child(reaction_checker)	
		
func _get_quark():
	return quark
	
func _on_button_pressed():
	toggle_reaction_bar()
	
func _on_like_changed():
	if not quark.liked:
		set_reaction_info("Лайк",DEFAULT_COLOR)
	else:
		_on_reaction_changed()	

func _on_reaction_changed():
	if not quark.liked:
		return
		
	var reaction_id = quark.reaction
	var reaction_name = reaction_bar.get_reaction_name(reaction_id)
	var color = reaction_bar.get_active_color(reaction_id)
	set_reaction_info(reaction_name,color)
	
func _on_reaction_selected():
	toggle_reaction_bar()

func _is_joypad_connected() -> bool:
	return not Input.get_connected_joypads().is_empty()

func _on_reaction_bar_hidden():
	if _is_joypad_connected():
		grab_focus()
