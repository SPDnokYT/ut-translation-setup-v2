extends Panel

var _last_shown_line_idx := -1


func _ready():
	visible = false
	for child in get_children():
		child.visible = false


func show_line(idx: int) -> void:
	assert(idx < 0 or idx < get_child_count())
	
	if _last_shown_line_idx >= 0:
		get_child(_last_shown_line_idx).visible = false
	
	_last_shown_line_idx = idx
	
	var show = idx >= 0
	visible = show
	if show:
		get_child(idx).visible = true


### Command handler ###
func _enter_tree():
	Story.add_command_handler(_run_command)


func _exit_tree():
	Story.remove_command_handler(_run_command)


func _run_command(cmd: Command):
	if cmd.name == "credits.show":
		var idx = int(cmd.params[0])
		show_line(idx)
		return null
	elif cmd.name == "credits.hide":
		# Если перед скрытием показывался последний оригинальный титр (Credits11, индекс 10)
		if _last_shown_line_idx == 10 and get_child_count() > 11:
			show_line(11) # Показываем наши титры (Credits12)
			await get_tree().create_timer(4.5).timeout # Ждём 4.5 секунды
		
		show_line(-1)
		return null
	else:
		return Constants.CMD_RETURN_NONE