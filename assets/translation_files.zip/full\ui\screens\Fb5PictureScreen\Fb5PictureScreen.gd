extends "../Screen.gd"

const FbPicture = preload("res://data/fb/FbPicture.gd")
const FbAtom = preload("res://data/fb/FbAtom.gd")
const FbMember = preload("res://data/fb/FbMember.gd")
const FbStatus = preload("res://data/fb/FbStatus.gd")
const FbAlbumPicture = preload("res://data/fb/FbAlbumPicture.gd")
const FbPictureTag = preload("res://ui/screens/FbPictureScreen/FbPictureTag.tscn")

@onready var author_title = $PanelContainer/Info/VBoxContainer/MarginContainer/Title
@onready var author_subtitle = $PanelContainer/Info/VBoxContainer/Subtitle
@onready var caption_container = $PanelContainer/Info/VBoxContainer/CaptionContainer
@onready var caption_label = $PanelContainer/Info/VBoxContainer/CaptionContainer/Label
@onready var expand_caption_btn = $PanelContainer/Info/VBoxContainer/CaptionContainer/MarginContainer/Expand

@onready var picture_component = $PictureComponent
@onready var stats_bar = $PanelContainer/Info/VBoxContainer/Fb5MediaStatsBar
@onready var menu_bar = $MenuBar
@onready var like_btn = $PanelContainer/Info/VBoxContainer/Fb5MediaStatsBar/Main/ActionsContainer/MarginContainer/Main/LikeButton

var atom: FbAtom
var _member: FbMember

func _ready():
	menu_bar.back_pressed.connect(_on_back_pressed)
	_member = FbUtils.get_member(atom.author_ref)
	
	expand_caption_btn.text = "Ещё"
	
	caption_label.minimum_size_changed.connect(_on_description_size_changed)
	expand_caption_btn.pressed.connect(_on_expand_button_pressed)
	author_title.meta_clicked.connect(_on_link_clicked)
	author_title.text = _member.name
	author_subtitle.text = FbUtils.timestamp_str_fb5(atom.timestamp)

	caption_container.visible = not atom.caption.is_empty()
	caption_label.text = atom.bbcode_caption
	load_picture()
	stats_bar.atom = atom

func load_picture():
	var fb_picture: FbPicture

	if atom is FbAlbumPicture:
		fb_picture = atom.fb_picture
	elif atom is FbStatus and atom.content is FbPicture:
		fb_picture = atom.content

	var pic_ref = fb_picture.picture_ref
	var image = load(pic_ref)

	picture_component.picture = image	
	
func _on_back_pressed():
	back_pressed.emit()

func _on_link_clicked(path):
	Service.of(Service.NAVIGATOR).push_named(path, {"new_fb_ui" : true})
	
func _on_expand_button_pressed():
	caption_label.expand_text()
	expand_caption_btn.visible = false
	expand_caption_btn.disabled = true
	
	if _is_joypad_connected():
		like_btn.grab_focus()
	
func _on_description_size_changed():
	expand_caption_btn.visible = caption_label.is_expandable() and not caption_label.is_expand

func _is_joypad_connected() -> bool:
	return not Input.get_connected_joypads().is_empty()
